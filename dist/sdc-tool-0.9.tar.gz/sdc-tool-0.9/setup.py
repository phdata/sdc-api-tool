#!/usr/bin/env python

from distutils.core import setup

setup(name='sdc-tool',
      version='0.9',
      description='Streamsets DataCollector API utility',
      author='phData inc',
      author_email='brian@phdata.io, tony@phdata.io',
      url='phdata.io',
      install_requires=['pyyaml', 'requests', 'pytest'],
      packages=['tools'],
      package_dir={'tools': 'src/tools'},
      scripts=['sdc-tool']
     )
